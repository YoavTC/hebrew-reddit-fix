# ![](https://raw.githubusercontent.com/YoavTC/hebrew-reddit-fix/refs/heads/master/icons/icon48.png) Hebrew Reddit Fix


**Hebrew Reddit Fix** fixes the problem with the left to right interface, by making a post's title, content, or description, right to left!
You can download the FireFox extension by visitng [this link](https://addons.mozilla.org/en-GB/firefox/addon/hebrew-reddit-rtl-fix/), or by downloading the ``hebrew-reddit-fix.zip`` manually.

![demo](https://raw.githubusercontent.com/YoavTC/hebrew-reddit-fix/refs/heads/master/media/demo.png)

## Additional Information
[![License](https://img.shields.io/badge/license-BY--NC--ND%204.0-lightgrey)](https://creativecommons.orglicenses/by-nc-nd/4.0/) [![Status](https://img.shields.io/badge/status-finished-gold)](.)
