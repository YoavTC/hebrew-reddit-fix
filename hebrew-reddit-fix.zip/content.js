// Regex to detect Hebrew characters
const hebrewRegex = /[\u0590-\u05FF]/;

document.querySelectorAll('p').forEach(p => {
    if (hebrewRegex.test(p.textContent)) {
        p.style.direction = 'rtl';
    }
});
